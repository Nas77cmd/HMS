@echo off
title Astronaut Health Monitoring Dashboard - Demo Launcher
color 0B
echo ============================================================
echo   Astronaut Health Monitoring ^& AI Medical Officer - Demo
echo ============================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js was not found on this machine.
    echo Please install Node.js 18+ from https://nodejs.org and re-run this file.
    pause
    exit /b 1
)

if not exist "node_modules" (
    echo [1/3] Installing dependencies ^(first run only, this can take a minute^)...
    call npm install
    if %errorlevel% neq 0 (
        echo [ERROR] npm install failed. See the messages above.
        pause
        exit /b 1
    )
) else (
    echo [1/3] Dependencies already installed, skipping npm install.
)

echo.
echo [2/3] Checking for a local Ollama install ^(optional, for offline AI reports^)...
where ollama >nul 2>nul
if %errorlevel% neq 0 (
    echo       Ollama was not found. The dashboard still works fully ^-
    echo       it will use its built-in rule-based Clinical Decision Support
    echo       engine instead of a local LLM. See models\README.md to add Ollama.
) else (
    echo       Ollama detected. Make sure it is running ^(ollama serve^) and that
    echo       you have pulled a model, e.g.  ollama pull qwen2.5:7b
)

echo.
echo [3/3] Starting the dashboard server...
echo       Once it is running, open this URL in your browser:
echo.
echo           http://localhost:3000
echo.
echo       Press CTRL+C in this window to stop the server.
echo ============================================================
echo.

call npm run dev

pause
