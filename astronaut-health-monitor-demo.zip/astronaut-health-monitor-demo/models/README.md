# Offline AI Model Folder

This app talks to a locally running **Ollama** server for fully offline AI report
generation (no internet/API key required). Ollama manages its own model store,
so you don't drop model files directly into this folder — instead you pull a
model once with Ollama's CLI and it becomes available automatically.

## Quick setup
1. Install Ollama: https://ollama.com/download
2. Pull a model (pick one that fits your laptop's RAM):
   ```
   ollama pull qwen2.5:7b      # good balance of quality/speed
   ollama pull qwen2.5:3b      # faster, lighter
   ollama pull llama3.2        # alternative
   ollama pull mistral         # alternative
   ```
3. Make sure Ollama is running (`ollama serve`, or just open the Ollama app).
4. In the dashboard, open **AI Settings -> Ollama** and select the model from
   the dropdown — it is detected automatically from your local Ollama install.

## Optional: custom GGUF models
If you have a custom GGUF file you'd like to use, create a `Modelfile` next to
it and register it with Ollama, e.g.:
```
ollama create my-custom-model -f Modelfile
```
It will then show up in the model dropdown like any other local model.

This `models/` folder is kept as a placeholder/drop-zone for Modelfiles or
notes about which model your team used for the demo — it is not read directly
by the app.
