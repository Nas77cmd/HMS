/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AlertSeverity = 'nominal' | 'caution' | 'warning' | 'critical';

export interface VitalsData {
  heartRate: number;
  heartRateVariability: number; // RMSSD in ms
  bloodPressure: string; // e.g. "118/76"
  systolic: number;
  diastolic: number;
  meanArterialPressure: number;
  spO2: number; // percentage
  respirationRate: number; // breaths per min
  temperature: number; // Celsius
  vo2Peak: number; // mL/kg/min
  endTidalCO2: number; // mmHg
  perfusionIndex: number;
}

export interface SansMetrics {
  opticNerveSheathDiameter: number; // mm (normal < 5.0mm, danger > 5.8mm)
  intraocularPressure: number; // mmHg (normal 10-21)
  intracranialPressureEst: number; // mmHg estimated
  frisenGrade: number; // 0 to 4 papilledema grade
  hyperopicShiftDiopters: number;
  cephaladFluidShiftPercent: number; // % blood/fluid pooled cephalad
  choroidalFoldsDetected: boolean;
  stage: 'Stage 0 (Nominal)' | 'Stage 1 (Subclinical)' | 'Stage 2 (Moderate SANS)' | 'Stage 3 (Severe SANS)';
}

export interface RadiationMetrics {
  dailyRate: number; // mSv/day (quiet sun 0.3-0.5, solar storm 10-100+)
  accumulated: number; // total mSv accumulated on mission
  careerCumulative: number; // total mSv including past flights
  careerLimitMsv: number; // typically 600 mSv based on NASA REID standard
  speRiskLevel: 'Nominal' | 'Guarded' | 'Elevated Alert' | 'Storm Shelter Warning';
  stormShelterActive: boolean;
  gcrFluxRate: number; // particles/cm2-s
  secondaryNeutronFlux: number; // mSv/hr
}

export interface EvaMetrics {
  active: boolean;
  sortieName?: string;
  durationMinutes: number;
  suitPressurePsi: number; // nominal 4.3 psi in EMU
  suitO2Purity: number; // % nominal 99.5%
  co2ScrubberRemainingPercent: number;
  metabolicRateBtu: number; // nominal 800 - 1800 BTU/hr
  coolingWaterTempC: number;
  batteryPercent: number;
  gloveSurfaceTempC: number;
  suitLeakRateSccm: number;
}

export interface CircadianMetrics {
  sleepScore: number; // 0-100
  sleepDurationHours: number;
  remSleepPercent: number;
  deepSleepPercent: number;
  phaseShiftHours: number; // relative to Houston / UTC nominal
  melatoninOnsetDelayMin: number;
  cognitiveReadinessScore: number; // 0-100
}

export interface Biomarkers {
  boneMineralDensityChange: number; // % change from baseline
  muscleMassChange: number; // % change from baseline
  lactateThresholdMmol: number;
  cortisolSerumUgDl: number;
  hsCRP: number; // mg/L inflammatory marker
  aredCompliancePercent: number;
}

export interface TelemetryAlert {
  id: string;
  timestamp: string;
  severity: AlertSeverity;
  category: 'Cardiovascular' | 'SANS/Neuro' | 'Radiation' | 'EVA Environmental' | 'Musculoskeletal';
  title: string;
  metric: string;
  currentValue: string;
  thresholdValue: string;
  clinicalSignificance: string;
  countermeasure: string;
  acknowledged: boolean;
}

export interface HistoricalTelemetryPoint {
  timeStr: string;
  timestamp: number;
  heartRate: number;
  systolic: number;
  diastolic: number;
  spO2: number;
  respirationRate: number;
  coreTemp: number;
  radiationRate: number;
  onsd: number;
  evaBtu?: number;
}

export interface CrewMember {
  id: string;
  name: string;
  callsign: string;
  role: string;
  agency: string;
  mission: string;
  flightClass: string;
  missionElapsedDays: number;
  overallStatus: AlertSeverity;
  bloodType: string;
  age: number;
  heightCm: number;
  weightKg: number;
  vitals: VitalsData;
  sansMetrics: SansMetrics;
  radiation: RadiationMetrics;
  eva: EvaMetrics;
  circadian: CircadianMetrics;
  biomarkers: Biomarkers;
  alerts: TelemetryAlert[];
  history24h: HistoricalTelemetryPoint[];
}

export interface OllamaModelInfo {
  name: string;
  size?: number;
  modified_at?: string;
  digest?: string;
}

export interface OllamaStatus {
  online: boolean;
  host: string;
  models: OllamaModelInfo[];
  message?: string;
  latencyMs?: number;
}

export type ReportType =
  | 'clinical_brief'
  | 'sans_assessment'
  | 'radiation_exposure'
  | 'eva_suit_biometrics'
  | 'sleep_circadian';

export type AIProvider = 'auto' | 'ollama' | 'gemini' | 'autonomous_offline_cds';

export interface AIReportResult {
  success: boolean;
  provider: AIProvider;
  model: string;
  host?: string;
  generationTimeMs: number;
  report: string;
  offlineAutonomy: boolean;
  notice?: string;
}
