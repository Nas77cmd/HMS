/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { INITIAL_CREW } from './data/crewData';
import { CrewMember, OllamaStatus, TelemetryAlert } from './types/telemetry';
import { Header } from './components/Header';
import { LiveECGMonitor } from './components/LiveECGMonitor';
import { VitalsGrid } from './components/VitalsGrid';
import { SansOcularMatrix } from './components/SansOcularMatrix';
import { RadiationDosimetry } from './components/RadiationDosimetry';
import { MusculoskeletalBoneChart } from './components/MusculoskeletalBoneChart';
import { EvaTelemetryCard } from './components/EvaTelemetryCard';
import { ClinicalDecisionSupport } from './components/ClinicalDecisionSupport';
import { OllamaConfigModal } from './components/OllamaConfigModal';
import { AIReportModal } from './components/AIReportModal';
import { checkOllamaStatus, DEFAULT_OLLAMA_HOST } from './services/aiService';
import { playTelemetryChime } from './utils/audioTelemetry';
import { 
  ShieldCheck, 
  Orbit, 
  Satellite, 
  Cpu, 
  FileText, 
  ExternalLink,
  Sparkles,
  Zap
} from 'lucide-react';

export default function App() {
  const [crew, setCrew] = useState<CrewMember[]>(INITIAL_CREW);
  const [selectedCrewId, setSelectedCrewId] = useState<string>(INITIAL_CREW[0].id);
  const [audioEnabled, setAudioEnabled] = useState<boolean>(false);

  // Ollama status & model selection
  const [ollamaStatus, setOllamaStatus] = useState<OllamaStatus>({
    online: false,
    host: DEFAULT_OLLAMA_HOST,
    models: [],
  });
  const [selectedOllamaModel, setSelectedOllamaModel] = useState<string>('');

  // Modals
  const [isOllamaModalOpen, setIsOllamaModalOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);

  // Active selected crew member
  const selectedCrew = crew.find((c) => c.id === selectedCrewId) || crew[0];

  // Initial check for Ollama daemon
  useEffect(() => {
    checkOllamaStatus(DEFAULT_OLLAMA_HOST).then((status) => {
      setOllamaStatus(status);
      if (status.models.length > 0) {
        setSelectedOllamaModel(status.models[0].name);
      }
    });
  }, []);

  // Subtle real-time telemetry heartbeat noise & mission drift simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setCrew((prevCrew) =>
        prevCrew.map((member) => {
          // Micro-fluctuations in physiological telemetry
          const hrDelta = Math.round((Math.random() - 0.5) * 2);
          const newHr = Math.max(50, Math.min(145, member.vitals.heartRate + hrDelta));
          const spo2Noise = Number(((Math.random() - 0.5) * 0.2).toFixed(1));
          const newSpo2 = Math.min(100, Math.max(96.0, Number((member.vitals.spO2 + spo2Noise).toFixed(1))));

          return {
            ...member,
            vitals: {
              ...member.vitals,
              heartRate: newHr,
              spO2: newSpo2,
            },
          };
        })
      );
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  // Handle countermeasure acknowledgment
  const handleAcknowledgeAlert = (alertId: string) => {
    if (audioEnabled) {
      playTelemetryChime('info');
    }

    setCrew((prevCrew) =>
      prevCrew.map((member) => {
        if (member.id !== selectedCrew.id) return member;

        const updatedAlerts = member.alerts.map((a) =>
          a.id === alertId ? { ...a, acknowledged: true } : a
        );

        const hasRemainingWarnings = updatedAlerts.some((a) => !a.acknowledged && a.severity === 'warning');
        const hasRemainingCaution = updatedAlerts.some((a) => !a.acknowledged && a.severity === 'caution');
        const newOverallStatus = hasRemainingWarnings ? 'warning' : hasRemainingCaution ? 'caution' : 'nominal';

        return {
          ...member,
          alerts: updatedAlerts,
          overallStatus: newOverallStatus,
        };
      })
    );
  };

  return (
    <div className="min-h-screen bg-[#060a14] text-slate-100 flex flex-col font-sans">
      {/* Flight Deck Mission Control Header */}
      <Header
        crew={crew}
        selectedCrew={selectedCrew}
        onSelectCrew={(c) => setSelectedCrewId(c.id)}
        audioEnabled={audioEnabled}
        onToggleAudio={() => setAudioEnabled((a) => !a)}
        ollamaStatus={ollamaStatus}
        onOpenOllamaConfig={() => setIsOllamaModalOpen(true)}
        onOpenReportModal={() => setIsReportModalOpen(true)}
      />

      {/* Main Mission Control Telemetry Surface */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-5 space-y-4">
        {/* Row 1: Real-time Lead II ECG Oscilloscope Sweep & Arrhythmia Monitor */}
        <section aria-label="ECG Rhythm Monitor">
          <LiveECGMonitor crew={selectedCrew} audioEnabled={audioEnabled} />
        </section>

        {/* Row 2: Four Core Hemodynamic, Pulmonary, Thermal & Fluid Telemetry Modules */}
        <section aria-label="Physiological Vitals Stream">
          <VitalsGrid crew={selectedCrew} />
        </section>

        {/* Row 3: Specialized BioAstronautics Domain Modules */}
        <section aria-label="Bioastronautics Diagnostics" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* SANS & Neuro-Ocular Matrix */}
          <SansOcularMatrix
            sans={selectedCrew.sansMetrics}
            crewName={selectedCrew.name}
          />

          {/* Cumulative Cosmic Radiation & Solar Particle Event Matrix */}
          <RadiationDosimetry
            radiation={selectedCrew.radiation}
            crewName={selectedCrew.name}
          />

          {/* Musculoskeletal, ARED Compliance & Circadian Sleep Score */}
          <MusculoskeletalBoneChart
            biomarkers={selectedCrew.biomarkers}
            circadian={selectedCrew.circadian}
            crewName={selectedCrew.name}
          />

          {/* EVA Spacewalk Biometrics & Life Support Telemetry */}
          <EvaTelemetryCard
            eva={selectedCrew.eva}
            crewName={selectedCrew.name}
          />
        </section>

        {/* Row 4: Clinical Decision Support & Anomaly Triage Matrix */}
        <section aria-label="Clinical Decision Support">
          <ClinicalDecisionSupport
            alerts={selectedCrew.alerts}
            onAcknowledgeAlert={handleAcknowledgeAlert}
            onOpenReportModal={() => setIsReportModalOpen(true)}
          />
        </section>

        {/* Space Apps Presentation Banner & Provenance Note */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-lg p-3 text-xs font-mono text-slate-400 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Orbit className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              NASA Space Apps Challenge · BioAstronautics Telemetry & Autonomous Clinical Support
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-500">
            <span>Class I Flight Medicine Standards</span>
            <span className="text-slate-700">·</span>
            <span>JSC Human Research Program (HRP)</span>
            <span className="text-slate-700">·</span>
            <span className="text-emerald-400/80 flex items-center gap-1">
              <Cpu className="w-3 h-3" />
              Ollama Offline Ready
            </span>
          </div>
        </div>
      </main>

      {/* Modals */}
      <OllamaConfigModal
        isOpen={isOllamaModalOpen}
        onClose={() => setIsOllamaModalOpen(false)}
        status={ollamaStatus}
        selectedModel={selectedOllamaModel}
        onSelectModel={(m) => setSelectedOllamaModel(m)}
        onUpdateStatus={(st) => setOllamaStatus(st)}
      />

      <AIReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        crew={selectedCrew}
        ollamaStatus={ollamaStatus}
        selectedOllamaModel={selectedOllamaModel}
      />
    </div>
  );
}
