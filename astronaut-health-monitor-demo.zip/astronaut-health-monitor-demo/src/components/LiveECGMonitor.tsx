/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState } from 'react';
import { Activity, Play, Pause, Zap, RefreshCw, Radio } from 'lucide-react';
import { CrewMember } from '../types/telemetry';
import { playHeartbeatBeep } from '../utils/audioTelemetry';

interface LiveECGMonitorProps {
  crew: CrewMember;
  audioEnabled: boolean;
}

export const LiveECGMonitor: React.FC<LiveECGMonitorProps> = ({ crew, audioEnabled }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isFrozen, setIsFrozen] = useState(false);
  const [selectedLead, setSelectedLead] = useState<'Lead I' | 'Lead II' | 'V1' | 'V5'>('Lead II');
  const [rhythmMode, setRhythmMode] = useState<'nominal' | 'pvc' | 'tachycardia'>('nominal');
  const [sweepSpeed, setSweepSpeed] = useState<25 | 50>(25);

  const heartRate = rhythmMode === 'tachycardia' ? 124 : crew.vitals.heartRate;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let sweepX = 0;
    let lastBeatTime = performance.now();
    let sampleIndex = 0;

    // Buffer to hold waveform points
    const width = canvas.width;
    const height = canvas.height;
    const midY = height / 2;

    // Grid draw function
    const drawGrid = () => {
      ctx.fillStyle = '#050c18';
      ctx.fillRect(0, 0, width, height);

      // Fine grid (1mm = ~5px)
      ctx.strokeStyle = '#0e243a';
      ctx.lineWidth = 0.5;

      const gridSize = 10;
      ctx.beginPath();
      for (let x = 0; x < width; x += gridSize) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
      }
      ctx.stroke();

      // Major grid (5mm = 50px)
      ctx.strokeStyle = '#163b5c';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = 0; x < width; x += gridSize * 5) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
      }
      for (let y = 0; y < height; y += gridSize * 5) {
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
      }
      ctx.stroke();
    };

    drawGrid();

    // ECG wave generator function (P-Q-R-S-T math)
    const getEcgOffset = (phase: number, isPvc = false): number => {
      // phase: 0.0 to 1.0 within cardiac cycle
      if (isPvc) {
        // Broad bizarre QRS complex for PVC
        if (phase < 0.15) return 0;
        if (phase < 0.25) return -Math.sin(((phase - 0.15) / 0.1) * Math.PI) * 12; // deep Q
        if (phase < 0.45) return Math.sin(((phase - 0.25) / 0.2) * Math.PI) * 48; // wide tall R
        if (phase < 0.6) return -Math.sin(((phase - 0.45) / 0.15) * Math.PI) * 20; // inverted T
        return 0;
      }

      // Normal Sinus Rhythm (Lead II)
      // P wave (atrial depolarization): 0.10 to 0.20
      if (phase >= 0.10 && phase < 0.22) {
        return Math.sin(((phase - 0.10) / 0.12) * Math.PI) * 7;
      }
      // PR segment is flat
      if (phase >= 0.22 && phase < 0.30) {
        return 0;
      }
      // Q wave (septal depolarization): slight downward
      if (phase >= 0.30 && phase < 0.33) {
        return -Math.sin(((phase - 0.30) / 0.03) * Math.PI) * 6;
      }
      // R peak (ventricular depolarization): sharp spike up
      if (phase >= 0.33 && phase < 0.38) {
        return Math.sin(((phase - 0.33) / 0.05) * Math.PI) * 52;
      }
      // S wave: downward plunge
      if (phase >= 0.38 && phase < 0.42) {
        return -Math.sin(((phase - 0.38) / 0.04) * Math.PI) * 14;
      }
      // ST segment: slightly elevated in microgravity
      if (phase >= 0.42 && phase < 0.52) {
        return 1.2;
      }
      // T wave (ventricular repolarization): smooth dome
      if (phase >= 0.52 && phase < 0.68) {
        return Math.sin(((phase - 0.52) / 0.16) * Math.PI) * 15;
      }
      // Baseline resting TP segment
      return 0;
    };

    let prevY = midY;
    let cycleDurationMs = (60 / heartRate) * 1000;
    let pvcTriggered = false;

    const render = (currentTime: number) => {
      if (!isFrozen) {
        cycleDurationMs = (60 / heartRate) * 1000;
        const elapsedSinceBeat = currentTime - lastBeatTime;

        let phase = (elapsedSinceBeat % cycleDurationMs) / cycleDurationMs;

        // Check if new beat started
        if (elapsedSinceBeat >= cycleDurationMs) {
          lastBeatTime = currentTime;
          // Random PVC check if in PVC mode
          pvcTriggered = rhythmMode === 'pvc' && Math.random() < 0.35;

          // Sound trigger at R-peak
          if (audioEnabled) {
            playHeartbeatBeep(heartRate, pvcTriggered);
          }
        }

        const leadMultiplier = selectedLead === 'V1' ? 0.7 : selectedLead === 'V5' ? 1.25 : 1.0;
        const rawOffset = getEcgOffset(phase, pvcTriggered) * leadMultiplier;
        const baselineDrift = Math.sin(currentTime * 0.001) * 2; // subtle respiratory variation
        const noise = (Math.random() - 0.5) * 1.0;
        const currentY = midY - (rawOffset + baselineDrift + noise);

        const step = sweepSpeed === 50 ? 3 : 2;

        // Erase ahead sweep zone
        const clearWidth = 24;
        ctx.fillStyle = '#050c18';
        ctx.fillRect(sweepX, 0, clearWidth, height);

        // Redraw faint grid in erased bar
        ctx.strokeStyle = '#0e243a';
        ctx.lineWidth = 0.5;
        ctx.beginPath();
        for (let x = sweepX; x < sweepX + clearWidth; x += 10) {
          ctx.moveTo(x, 0);
          ctx.lineTo(x, height);
        }
        for (let y = 0; y < height; y += 10) {
          ctx.moveTo(sweepX, y);
          ctx.lineTo(sweepX + clearWidth, y);
        }
        ctx.stroke();

        // Draw ECG glowing trace
        ctx.strokeStyle = '#10b981'; // vibrant medical emerald
        ctx.lineWidth = 2.2;
        ctx.shadowColor = '#34d399';
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.moveTo(sweepX > 0 ? sweepX - step : 0, prevY);
        ctx.lineTo(sweepX, currentY);
        ctx.stroke();
        ctx.shadowBlur = 0; // reset blur

        // Draw bright sweep scanhead dot
        ctx.fillStyle = '#6ee7b7';
        ctx.beginPath();
        ctx.arc(sweepX, currentY, 2.5, 0, Math.PI * 2);
        ctx.fill();

        prevY = currentY;
        sweepX += step;
        if (sweepX >= width) {
          sweepX = 0;
          prevY = midY;
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [heartRate, selectedLead, rhythmMode, sweepSpeed, isFrozen, audioEnabled]);

  return (
    <div className="bg-slate-900/90 border border-cyan-950/70 rounded-lg p-3.5 shadow-lg relative overflow-hidden">
      {/* Header telemetry info */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-2 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-400">
            <Activity className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 font-mono">
              <span className="font-bold text-slate-100 text-sm">BIO-TELEMETRY ECG</span>
              <span className="text-slate-500">·</span>
              <span className="text-emerald-400 font-semibold">{selectedLead}</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-400">{sweepSpeed} mm/s · 10 mm/mV</span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              {rhythmMode === 'nominal'
                ? 'Normal Sinus Rhythm · Autonomic tone stable'
                : rhythmMode === 'pvc'
                ? 'Isolated Premature Ventricular Contractions (PVC)'
                : 'Sinus Tachycardia secondary to EVA metabolic resistance'}
            </p>
          </div>
        </div>

        {/* Real-time Electrocardiographic Intervals Readout */}
        <div className="flex items-center gap-3 font-mono text-[11px] bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
          <div>
            <span className="text-slate-500 text-[10px] block">HR (BPM)</span>
            <span className="text-lg font-bold text-emerald-400 leading-none">{heartRate}</span>
          </div>
          <div className="h-6 w-px bg-slate-800" />
          <div>
            <span className="text-slate-500 text-[10px] block">PR INT</span>
            <span className="font-semibold text-slate-200">158 ms</span>
          </div>
          <div className="h-6 w-px bg-slate-800" />
          <div>
            <span className="text-slate-500 text-[10px] block">QRS DUR</span>
            <span className="font-semibold text-slate-200">88 ms</span>
          </div>
          <div className="h-6 w-px bg-slate-800" />
          <div>
            <span className="text-slate-500 text-[10px] block">QTc</span>
            <span className="font-semibold text-slate-200">408 ms</span>
          </div>
          <div className="h-6 w-px bg-slate-800" />
          <div>
            <span className="text-slate-500 text-[10px] block">ST DEV</span>
            <span className="font-semibold text-emerald-400">+0.02 mV</span>
          </div>
        </div>
      </div>

      {/* Canvas Oscilloscope Monitor */}
      <div className="relative w-full rounded border border-slate-800 bg-[#050c18] overflow-hidden">
        <canvas
          ref={canvasRef}
          width={800}
          height={160}
          className="w-full h-40 block cursor-crosshair"
          title="Lead II Real-time Oscilloscope Vector"
        />

        {/* Ambient telemetry overlay watermark */}
        <div className="absolute top-2 left-3 font-mono text-[10px] text-emerald-500/60 pointer-events-none select-none">
          CH-01 · 250 Hz FILTER · BIO-SIGNAL DSP ACTIVE
        </div>

        {isFrozen && (
          <div className="absolute top-2 right-3 bg-red-950/80 border border-red-500/60 text-red-300 font-mono text-[10px] px-2 py-0.5 rounded">
            TRACE FREEZE (CALIPER MODE)
          </div>
        )}
      </div>

      {/* Control Strip & Simulation Trigger */}
      <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
        {/* Lead selection tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded border border-slate-800">
          {(['Lead I', 'Lead II', 'V1', 'V5'] as const).map((lead) => (
            <button
              key={lead}
              onClick={() => setSelectedLead(lead)}
              className={`px-2 py-0.5 rounded transition-all ${
                selectedLead === lead
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {lead}
            </button>
          ))}
        </div>

        {/* Speed & Freeze Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setSweepSpeed((s) => (s === 25 ? 50 : 25))}
            className="px-2 py-1 rounded bg-slate-950 text-slate-300 border border-slate-800 hover:border-slate-700"
            title="Toggle Sweep Speed (25 / 50 mm/s)"
          >
            {sweepSpeed} mm/s
          </button>

          <button
            onClick={() => setIsFrozen((f) => !f)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded border transition-all ${
              isFrozen
                ? 'bg-amber-950/60 text-amber-300 border-amber-500/50'
                : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
            }`}
          >
            {isFrozen ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
            <span>{isFrozen ? 'RESUME' : 'FREEZE'}</span>
          </button>
        </div>

        {/* Arrhythmia Simulation Triage Selector */}
        <div className="flex items-center gap-1.5 text-slate-400">
          <Zap className="w-3 h-3 text-amber-400" />
          <span className="text-[10px] text-slate-400 uppercase">Simulate Cardiac Stress:</span>
          <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded border border-slate-800">
            <button
              onClick={() => setRhythmMode('nominal')}
              className={`px-2 py-0.5 rounded text-[11px] transition-all ${
                rhythmMode === 'nominal'
                  ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/50'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Nominal
            </button>
            <button
              onClick={() => setRhythmMode('tachycardia')}
              className={`px-2 py-0.5 rounded text-[11px] transition-all ${
                rhythmMode === 'tachycardia'
                  ? 'bg-amber-950/80 text-amber-300 border border-amber-500/50'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Tachycardia
            </button>
            <button
              onClick={() => setRhythmMode('pvc')}
              className={`px-2 py-0.5 rounded text-[11px] transition-all ${
                rhythmMode === 'pvc'
                  ? 'bg-red-950/80 text-red-300 border border-red-500/50'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              PVC Ectopy
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
