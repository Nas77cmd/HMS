/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Heart, 
  Wind, 
  Thermometer, 
  TrendingUp, 
  Droplet, 
  ShieldCheck, 
  AlertTriangle,
  Info
} from 'lucide-react';
import { CrewMember, HistoricalTelemetryPoint } from '../types/telemetry';

interface VitalsGridProps {
  crew: CrewMember;
}

export const VitalsGrid: React.FC<VitalsGridProps> = ({ crew }) => {
  const [tempUnit, setTempUnit] = useState<'C' | 'F'>('C');
  const [activeMetricTab, setActiveMetricTab] = useState<'all' | 'cardio' | 'pulmonary' | 'thermal'>('all');
  const [hoveredPoint, setHoveredPoint] = useState<HistoricalTelemetryPoint | null>(null);

  const vitals = crew.vitals;
  const history = crew.history24h;

  const displayTemp = (celsius: number) => {
    if (tempUnit === 'F') {
      return ((celsius * 9) / 5 + 32).toFixed(1);
    }
    return celsius.toFixed(1);
  };

  // SVG sparkline builder with interactive points
  const renderSparkline = (
    data: number[],
    color: string,
    minVal?: number,
    maxVal?: number,
    metricKey?: keyof HistoricalTelemetryPoint
  ) => {
    if (data.length === 0) return null;
    const min = minVal !== undefined ? minVal : Math.min(...data) * 0.95;
    const max = maxVal !== undefined ? maxVal : Math.max(...data) * 1.05;
    const range = max - min || 1;

    const width = 240;
    const height = 48;

    const points = data.map((val, idx) => {
      const x = (idx / (data.length - 1)) * width;
      const y = height - ((val - min) / range) * (height - 8) - 4;
      return { x, y, val, original: history[idx] };
    });

    const pathD = points.reduce((acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`, '');

    return (
      <div className="relative group/sparkline">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-12 overflow-visible stroke-linecap-round"
        >
          {/* Subtle filled gradient area */}
          <defs>
            <linearGradient id={`grad-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity="0.25" />
              <stop offset="100%" stopColor={color} stopOpacity="0.0" />
            </linearGradient>
          </defs>
          <path
            d={`${pathD} L ${width} ${height} L 0 ${height} Z`}
            fill={`url(#grad-${color.replace('#', '')})`}
          />
          {/* Main stroke line */}
          <path
            d={pathD}
            fill="none"
            stroke={color}
            strokeWidth="1.8"
            className="transition-all"
          />
          {/* Interactive dots on points */}
          {points.map((pt, i) => (
            <circle
              key={i}
              cx={pt.x}
              cy={pt.y}
              r={i === points.length - 1 ? 3 : 1.5}
              fill={color}
              className="hover:r-4 transition-all cursor-pointer opacity-70 hover:opacity-100"
              onMouseEnter={() => setHoveredPoint(pt.original)}
              onMouseLeave={() => setHoveredPoint(null)}
            />
          ))}
        </svg>
      </div>
    );
  };

  const hrHistory = history.map((p) => p.heartRate);
  const sysHistory = history.map((p) => p.systolic);
  const spo2History = history.map((p) => p.spO2);
  const tempHistory = history.map((p) => p.coreTemp);

  return (
    <div className="space-y-3">
      {/* Metric Filtering and Hover Tooltip Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
        <div className="flex items-center gap-1.5 text-slate-400">
          <span className="uppercase text-[10px] text-slate-500">Telemetry Stream:</span>
          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded border border-slate-800">
            {(['all', 'cardio', 'pulmonary', 'thermal'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveMetricTab(tab)}
                className={`px-2 py-0.5 rounded capitalize transition-all ${
                  activeMetricTab === tab
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Hovered Point Inspector */}
        <div className="font-mono text-[11px] text-slate-300">
          {hoveredPoint ? (
            <span className="text-cyan-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
              T-{hoveredPoint.timeStr}: HR {hoveredPoint.heartRate} BPM · SpO2 {hoveredPoint.spO2}% · {hoveredPoint.systolic}/{hoveredPoint.diastolic} mmHg
            </span>
          ) : (
            <span className="text-slate-500">Hover historical points to inspect 24h trend</span>
          )}
        </div>
      </div>

      {/* Grid of 4 Core Physiological Telemetry Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* 1. Hemodynamics & Heart Rate */}
        {(activeMetricTab === 'all' || activeMetricTab === 'cardio') && (
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between hover:border-slate-700 transition-all">
            <div>
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-800/80 mb-2">
                <div className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-rose-400 animate-pulse" />
                  <span className="font-mono font-bold text-slate-200 text-xs">HEMODYNAMICS</span>
                </div>
                <span
                  className={`font-mono text-[10px] px-1.5 py-0.2 rounded border ${
                    vitals.heartRate > 105
                      ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                      : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  }`}
                >
                  {vitals.heartRate > 105 ? 'ELEVATED' : 'NOMINAL'}
                </span>
              </div>

              {/* Big primary number */}
              <div className="flex items-baseline justify-between mb-1">
                <div>
                  <span className="font-mono text-2xl font-bold text-slate-100">{vitals.heartRate}</span>
                  <span className="font-mono text-xs text-slate-400 ml-1">BPM</span>
                </div>
                <div className="text-right">
                  <span className="font-mono text-sm font-semibold text-cyan-300">{vitals.bloodPressure}</span>
                  <span className="font-mono text-[10px] text-slate-500 ml-1">mmHg</span>
                </div>
              </div>

              {/* Secondary Clinical Derivatives */}
              <div className="grid grid-cols-3 gap-1.5 my-2.5 font-mono text-[10px] bg-slate-950 p-2 rounded border border-slate-800/60">
                <div>
                  <span className="text-slate-500 block">MAP</span>
                  <span className="font-semibold text-slate-200">{vitals.meanArterialPressure} mmHg</span>
                </div>
                <div>
                  <span className="text-slate-500 block">PULSE PR</span>
                  <span className="font-semibold text-slate-200">{vitals.systolic - vitals.diastolic} mmHg</span>
                </div>
                <div>
                  <span className="text-slate-500 block">HRV (RMSSD)</span>
                  <span className="font-semibold text-emerald-400">{vitals.heartRateVariability} ms</span>
                </div>
              </div>
            </div>

            {/* Sparkline */}
            <div>
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 mb-1">
                <span>24H Heart Rate Trend</span>
                <span>Range: 55-120</span>
              </div>
              {renderSparkline(hrHistory, '#f43f5e', 50, 130, 'heartRate')}
            </div>
          </div>
        )}

        {/* 2. Gas Exchange & Respiration */}
        {(activeMetricTab === 'all' || activeMetricTab === 'pulmonary') && (
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between hover:border-slate-700 transition-all">
            <div>
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-800/80 mb-2">
                <div className="flex items-center gap-2">
                  <Wind className="w-4 h-4 text-cyan-400" />
                  <span className="font-mono font-bold text-slate-200 text-xs">PULMONARY / SpO2</span>
                </div>
                <span className="font-mono text-[10px] px-1.5 py-0.2 rounded border bg-emerald-500/10 text-emerald-400 border-emerald-500/30">
                  OPTIMAL
                </span>
              </div>

              <div className="flex items-baseline justify-between mb-1">
                <div>
                  <span className="font-mono text-2xl font-bold text-slate-100">{vitals.spO2}</span>
                  <span className="font-mono text-xs text-slate-400 ml-1">% SpO2</span>
                </div>
                <div className="text-right">
                  <span className="font-mono text-sm font-semibold text-cyan-300">{vitals.respirationRate}</span>
                  <span className="font-mono text-[10px] text-slate-500 ml-1">br/min</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-1.5 my-2.5 font-mono text-[10px] bg-slate-950 p-2 rounded border border-slate-800/60">
                <div>
                  <span className="text-slate-500 block">EtCO2</span>
                  <span className="font-semibold text-slate-200">{vitals.endTidalCO2} kPa</span>
                </div>
                <div>
                  <span className="text-slate-500 block">PERF IDX</span>
                  <span className="font-semibold text-slate-200">{vitals.perfusionIndex}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block">CABIN O2</span>
                  <span className="font-semibold text-cyan-400">21.0%</span>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 mb-1">
                <span>24H Arterial O2 Saturation</span>
                <span>Range: 96-100%</span>
              </div>
              {renderSparkline(spo2History, '#06b6d4', 95, 100, 'spO2')}
            </div>
          </div>
        )}

        {/* 3. Thermoregulation & Aerobic Capacity */}
        {(activeMetricTab === 'all' || activeMetricTab === 'thermal') && (
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between hover:border-slate-700 transition-all">
            <div>
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-800/80 mb-2">
                <div className="flex items-center gap-2">
                  <Thermometer className="w-4 h-4 text-amber-400" />
                  <span className="font-mono font-bold text-slate-200 text-xs">THERMAL & VO2</span>
                </div>
                <button
                  onClick={() => setTempUnit((u) => (u === 'C' ? 'F' : 'C'))}
                  className="font-mono text-[10px] px-1.5 py-0.2 rounded border bg-slate-950 border-slate-800 text-slate-300 hover:text-cyan-300"
                  title="Toggle Celsius / Fahrenheit"
                >
                  °{tempUnit}
                </button>
              </div>

              <div className="flex items-baseline justify-between mb-1">
                <div>
                  <span className="font-mono text-2xl font-bold text-slate-100">{displayTemp(vitals.temperature)}</span>
                  <span className="font-mono text-xs text-slate-400 ml-1">°{tempUnit}</span>
                </div>
                <div className="text-right">
                  <span className="font-mono text-sm font-semibold text-amber-300">{vitals.vo2Peak}</span>
                  <span className="font-mono text-[10px] text-slate-500 ml-1">VO2 max</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-1.5 my-2.5 font-mono text-[10px] bg-slate-950 p-2 rounded border border-slate-800/60">
                <div>
                  <span className="text-slate-500 block">SKIN TEMP</span>
                  <span className="font-semibold text-slate-200">{displayTemp(vitals.temperature - 2.4)}°{tempUnit}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">NADIR MET</span>
                  <span className="font-semibold text-slate-200">04:30 UTC</span>
                </div>
                <div>
                  <span className="text-slate-500 block">CAL BURNT</span>
                  <span className="font-semibold text-amber-400">2,480 kcal</span>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 mb-1">
                <span>24H Core Body Temp</span>
                <span>Range: 36.4 - 37.6°C</span>
              </div>
              {renderSparkline(tempHistory, '#f59e0b', 36.2, 37.8, 'coreTemp')}
            </div>
          </div>
        )}

        {/* 4. Cephalad Fluid Shift & Microgravity Adaptation */}
        {activeMetricTab === 'all' && (
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between hover:border-slate-700 transition-all">
            <div>
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-800/80 mb-2">
                <div className="flex items-center gap-2">
                  <Droplet className="w-4 h-4 text-indigo-400" />
                  <span className="font-mono font-bold text-slate-200 text-xs">FLUID DISTRIBUTION</span>
                </div>
                <span
                  className={`font-mono text-[10px] px-1.5 py-0.2 rounded border ${
                    crew.sansMetrics.cephaladFluidShiftPercent > 15
                      ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                      : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                  }`}
                >
                  +{crew.sansMetrics.cephaladFluidShiftPercent}% CEPHALAD
                </span>
              </div>

              <div className="flex items-baseline justify-between mb-1">
                <div>
                  <span className="font-mono text-2xl font-bold text-indigo-300">
                    +{crew.sansMetrics.cephaladFluidShiftPercent}%
                  </span>
                  <span className="font-mono text-xs text-slate-400 ml-1">shift</span>
                </div>
                <div className="text-right">
                  <span className="font-mono text-sm font-semibold text-slate-200">
                    {crew.sansMetrics.intraocularPressure}
                  </span>
                  <span className="font-mono text-[10px] text-slate-500 ml-1">IOP mmHg</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-1.5 my-2.5 font-mono text-[10px] bg-slate-950 p-2 rounded border border-slate-800/60">
                <div>
                  <span className="text-slate-500 block">IJV DOPPLER</span>
                  <span className="font-semibold text-slate-200">Laminar</span>
                </div>
                <div>
                  <span className="text-slate-500 block">ORTHO RISK</span>
                  <span className="font-semibold text-emerald-400">Class II</span>
                </div>
                <div>
                  <span className="text-slate-500 block">LBNP TARGET</span>
                  <span className="font-semibold text-cyan-400">-25 mmHg</span>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 mb-1">
                <span>Blood Pressure Systolic 24H</span>
                <span>Range: 105-140</span>
              </div>
              {renderSparkline(sysHistory, '#818cf8', 100, 145, 'systolic')}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
