/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  X, 
  Cpu, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Terminal, 
  ExternalLink,
  Zap,
  Server
} from 'lucide-react';
import { OllamaModelInfo, OllamaStatus } from '../types/telemetry';
import { checkOllamaStatus, DEFAULT_OLLAMA_HOST } from '../services/aiService';

interface OllamaConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: OllamaStatus;
  selectedModel: string;
  onSelectModel: (model: string) => void;
  onUpdateStatus: (newStatus: OllamaStatus) => void;
}

export const OllamaConfigModal: React.FC<OllamaConfigModalProps> = ({
  isOpen,
  onClose,
  status,
  selectedModel,
  onSelectModel,
  onUpdateStatus,
}) => {
  const [hostInput, setHostInput] = useState(status.host || DEFAULT_OLLAMA_HOST);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);

    const updated = await checkOllamaStatus(hostInput);
    onUpdateStatus(updated);
    setIsTesting(false);

    if (updated.online) {
      setTestResult(`Successfully connected to Ollama (${updated.latencyMs}ms latency). ${updated.models.length} model(s) discovered.`);
      if (updated.models.length > 0 && !selectedModel) {
        onSelectModel(updated.models[0].name);
      }
    } else {
      setTestResult(`Connection failed to ${hostInput}. Ensure Ollama is running.`);
    }
  };

  const formatSize = (bytes?: number) => {
    if (!bytes) return '';
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-cyan-950/80 rounded-xl max-w-xl w-full shadow-2xl overflow-hidden font-mono text-xs">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded bg-emerald-950/70 border border-emerald-500/40 text-emerald-400">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-slate-100 text-sm">OLLAMA OFFLINE LLM ENGINE CONFIGURATION</h2>
              <p className="text-[11px] text-slate-400">Deep Space Autonomous Local Onboard Inference</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Status Banner */}
          <div
            className={`p-3 rounded-lg border flex items-start gap-3 ${
              status.online
                ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                : 'bg-amber-950/20 border-amber-500/30 text-amber-300'
            }`}
          >
            {status.online ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            )}
            <div>
              <div className="font-bold text-xs">
                {status.online ? 'OLLAMA DAEMON ACTIVE & READY' : 'OLLAMA DAEMON STANDBY / NOT DETECTED'}
              </div>
              <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                {status.online
                  ? `Connected to ${status.host}. Offline AI medical telemetry generation will execute locally on this machine without Earth uplink.`
                  : `No response from ${status.host}. Flight Surgeon AI will gracefully use the Autonomous Bio-CDS Core or Gemini uplink until Ollama is launched.`}
              </p>
            </div>
          </div>

          {/* Endpoint URL Input */}
          <div className="space-y-1.5">
            <label className="text-slate-300 font-semibold block text-[11px] uppercase tracking-wider">
              Ollama Host Endpoint URL
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Server className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={hostInput}
                  onChange={(e) => setHostInput(e.target.value)}
                  placeholder="http://127.0.0.1:11434"
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 pl-9 text-slate-200 focus:outline-none focus:border-cyan-500 text-xs"
                />
              </div>
              <button
                onClick={handleTestConnection}
                disabled={isTesting}
                className="px-3.5 py-2 rounded bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-bold transition-all flex items-center gap-1.5 shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                <span>{isTesting ? 'PINGING...' : 'TEST PING'}</span>
              </button>
            </div>
            {testResult && (
              <p className={`text-[11px] mt-1 ${status.online ? 'text-emerald-400' : 'text-amber-400'}`}>
                {testResult}
              </p>
            )}
          </div>

          {/* Model Selection */}
          <div className="space-y-1.5">
            <label className="text-slate-300 font-semibold block text-[11px] uppercase tracking-wider">
              Installed Ollama Models ({status.models.length} Discovered)
            </label>
            {status.models.length > 0 ? (
              <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                {status.models.map((m) => {
                  const isCurrent = selectedModel === m.name;
                  return (
                    <button
                      key={m.name}
                      onClick={() => onSelectModel(m.name)}
                      className={`w-full flex items-center justify-between p-2 rounded border text-left transition-all ${
                        isCurrent
                          ? 'bg-cyan-950/80 border-cyan-500/70 text-cyan-200'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Zap className={`w-3.5 h-3.5 ${isCurrent ? 'text-cyan-400' : 'text-slate-600'}`} />
                        <span className="font-bold text-slate-200">{m.name}</span>
                      </div>
                      <span className="text-[10px] text-slate-500">{formatSize(m.size)}</span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="bg-slate-950 p-3 rounded border border-slate-800 text-slate-400 text-xs">
                No local models detected yet. Pull a model such as <code className="text-cyan-300">llama3</code> or <code className="text-cyan-300">mistral</code>.
              </div>
            )}
          </div>

          {/* Quick Setup Instructions for Space Apps Presentation */}
          <div className="bg-slate-950 p-3.5 rounded border border-slate-800/80 space-y-2">
            <div className="flex items-center gap-1.5 text-slate-300 font-semibold text-[11px]">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>TERMINAL SETUP INSTRUCTIONS:</span>
            </div>
            <div className="space-y-1 text-[11px] text-slate-400">
              <p>To start Ollama on your machine for the offline challenge demo:</p>
              <div className="bg-slate-900 p-2 rounded border border-slate-800 text-cyan-300 select-all font-mono text-[11px]">
                ollama run llama3
              </div>
              <p className="text-[10px] text-slate-500 mt-1">
                If connecting from an external host, enable origins: <code className="text-slate-400">OLLAMA_ORIGINS="*" ollama serve</code>
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-950 border-t border-slate-800 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs"
          >
            DISMISS
          </button>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs"
          >
            SAVE & CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
