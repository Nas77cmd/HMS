/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  X, 
  FileText, 
  Cpu, 
  Sparkles, 
  Download, 
  Copy, 
  Check, 
  Printer, 
  RefreshCw, 
  ShieldCheck, 
  Clock, 
  AlertCircle,
  ExternalLink
} from 'lucide-react';
import { AIProvider, AIReportResult, CrewMember, OllamaStatus, ReportType } from '../types/telemetry';
import { generateMedicalReport } from '../services/aiService';

interface AIReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  crew: CrewMember;
  ollamaStatus: OllamaStatus;
  selectedOllamaModel: string;
}

export const AIReportModal: React.FC<AIReportModalProps> = ({
  isOpen,
  onClose,
  crew,
  ollamaStatus,
  selectedOllamaModel,
}) => {
  const [reportType, setReportType] = useState<ReportType>('clinical_brief');
  const [provider, setProvider] = useState<AIProvider>(ollamaStatus.online ? 'ollama' : 'auto');
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<AIReportResult | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    setIsGenerating(true);
    setResult(null);

    const res = await generateMedicalReport({
      astronaut: crew,
      reportType,
      provider,
      ollamaModel: selectedOllamaModel || 'llama3:latest',
      ollamaHost: ollamaStatus.host,
    });

    setResult(res);
    setIsGenerating(false);
  };

  const handleCopyMarkdown = () => {
    if (!result?.report) return;
    navigator.clipboard.writeText(result.report);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadJson = () => {
    const payload = {
      mission: 'Artemis Expedition IX',
      crewmember: crew.name,
      id: crew.id,
      timestamp: new Date().toISOString(),
      reportType,
      generatedVia: result?.provider,
      modelUsed: result?.model,
      vitalsSnapshot: crew.vitals,
      sansSnapshot: crew.sansMetrics,
      radiationSnapshot: crew.radiation,
      evaSnapshot: crew.eva,
      clinicalReportText: result?.report,
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Flight Surgeon AI-Medical-Record-${crew.id}-MET142.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrintPdf = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md print:bg-white print:p-0">
      <div className="bg-slate-900 border border-cyan-900/80 rounded-xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden print:border-none print:shadow-none print:bg-white print:max-h-none print:text-black">
        {/* Header Ribbon */}
        <div className="flex items-center justify-between px-5 py-3 bg-slate-950 border-b border-slate-800 print:hidden font-mono text-xs">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded bg-cyan-950/80 border border-cyan-500/50 text-cyan-400">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-slate-100 text-sm">
                FLIGHT SURGEON AI AUTONOMOUS FLIGHT SURGEON REPORT SYNTHESIZER
              </h2>
              <p className="text-[11px] text-slate-400">
                NASA Bioastronautics Clinical Decision Support System · Space Apps Challenge
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Configuration Bar (Hidden in Print) */}
        <div className="p-4 bg-slate-950/60 border-b border-slate-800/80 space-y-3 print:hidden font-mono text-xs">
          {/* Row 1: Engine Selection */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-slate-400 uppercase text-[10px]">AI Compute Engine:</span>
              <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded border border-slate-800">
                <button
                  onClick={() => setProvider('ollama')}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded transition-all ${
                    provider === 'ollama'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50 font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Local offline LLM (zero network uplink required)"
                >
                  <Cpu className="w-3.5 h-3.5" />
                  <span>Ollama (Offline Local)</span>
                  {ollamaStatus.online && (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  )}
                </button>

                <button
                  onClick={() => setProvider('gemini')}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded transition-all ${
                    provider === 'gemini'
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Deep space cloud relay via Gemini 3.8 Flash"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Gemini 3.8 Flash</span>
                </button>

                <button
                  onClick={() => setProvider('auto')}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded transition-all ${
                    provider === 'auto'
                      ? 'bg-indigo-950 text-indigo-300 border border-indigo-500/50 font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Auto-select fastest: Ollama first, then Gemini, then Autonomous"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Auto-Negotiate</span>
                </button>

                <button
                  onClick={() => setProvider('autonomous_offline_cds')}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded transition-all ${
                    provider === 'autonomous_offline_cds'
                      ? 'bg-slate-800 text-slate-100 border border-slate-600 font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Deterministic onboard clinical algorithm"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Autonomous CDS Core</span>
                </button>
              </div>
            </div>

            {/* Offline Autonomy Status Tag */}
            <div className="flex items-center gap-1 text-[11px]">
              {provider === 'ollama' ? (
                ollamaStatus.online ? (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    Offline Compute Verified ({selectedOllamaModel || 'llama3'})
                  </span>
                ) : (
                  <span className="text-amber-400 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    Ollama offline (Autonomous CDS fail-safe will handle)
                  </span>
                )
              ) : provider === 'autonomous_offline_cds' ? (
                <span className="text-cyan-400 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  100% Air-Gapped Spacecraft Mode
                </span>
              ) : (
                <span className="text-slate-400">Deep Space Ground Relay</span>
              )}
            </div>
          </div>

          {/* Row 2: Template Selection & Primary Trigger Button */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-2">
              <span className="text-slate-400 uppercase text-[10px]">Clinical Focus:</span>
              <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded border border-slate-800">
                {(
                  [
                    { id: 'clinical_brief', label: 'Flight Level 1 Summary' },
                    { id: 'sans_assessment', label: 'SANS & Neuro-Ocular' },
                    { id: 'radiation_exposure', label: 'Radiation Dosimetry' },
                  ] as const
                ).map((tpl) => (
                  <button
                    key={tpl.id}
                    onClick={() => setReportType(tpl.id)}
                    className={`px-2.5 py-1 rounded transition-all ${
                      reportType === tpl.id
                        ? 'bg-cyan-950 text-cyan-200 border border-cyan-500/50'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {tpl.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Generate Action Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="px-5 py-2 rounded bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-[0_0_14px_rgba(6,182,212,0.4)] transition-all flex items-center gap-2 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
              <span>{isGenerating ? 'SYNTHESIZING REPORT...' : 'GENERATE NASA MEDICAL REPORT'}</span>
            </button>
          </div>
        </div>

        {/* Content Area / Report Display */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7 space-y-4 font-mono text-xs bg-slate-950/40">
          {isGenerating ? (
            <div className="py-20 flex flex-col items-center justify-center text-center space-y-3 font-mono">
              <div className="relative">
                <div className="w-12 h-12 rounded-full border-2 border-cyan-500/20 border-t-cyan-400 animate-spin" />
                <Cpu className="w-5 h-5 text-cyan-400 absolute top-3.5 left-3.5 animate-pulse" />
              </div>
              <div className="text-sm font-bold text-slate-200 tracking-wide">
                SYNTHESIZING FLIGHT SURGEON DISPOSITION
              </div>
              <p className="text-xs text-slate-400 max-w-md">
                Analyzing real-time Lead II rhythm telemetry, ONSD optic sheath dilation, GCR cumulative ionizing flux, and metabolic gas exchange...
              </p>
            </div>
          ) : result ? (
            <div className="space-y-4">
              {/* Generation Telemetry Tag */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded bg-slate-900 border border-slate-800 text-[11px] print:hidden">
                <div className="flex items-center gap-3">
                  <span className="text-slate-400">
                    Engine:{' '}
                    <strong className="text-cyan-300">
                      {result.provider === 'ollama'
                        ? `Ollama (${result.model})`
                        : result.provider === 'gemini'
                        ? 'Google Gemini 3.8 Flash'
                        : 'Autonomous Bio-CDS Core v4.2'}
                    </strong>
                  </span>
                  <span className="text-slate-600">·</span>
                  <span className="text-slate-400">
                    Latency: <strong className="text-slate-200">{result.generationTimeMs}ms</strong>
                  </span>
                  <span className="text-slate-600">·</span>
                  <span
                    className={
                      result.offlineAutonomy
                        ? 'text-emerald-400 font-semibold'
                        : 'text-cyan-400 font-semibold'
                    }
                  >
                    {result.offlineAutonomy ? '100% Offline Autonomy' : 'Online Uplink'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyMarkdown}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'COPIED' : 'COPY MARKDOWN'}</span>
                  </button>
                  <button
                    onClick={handleDownloadJson}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>DOWNLOAD JSON</span>
                  </button>
                  <button
                    onClick={handlePrintPdf}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-cyan-700 hover:bg-cyan-600 text-slate-950 font-bold transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>PRINT / PDF</span>
                  </button>
                </div>
              </div>

              {result.notice && (
                <div className="p-2.5 rounded bg-amber-950/20 border border-amber-500/30 text-amber-300 text-[11px] print:hidden">
                  {result.notice}
                </div>
              )}

              {/* Styled Report Output */}
              <div className="p-6 rounded-lg bg-slate-900/90 border border-slate-800/80 text-slate-200 shadow-inner space-y-4 print:bg-white print:border-none print:text-black">
                {/* Official NASA Clinical Header Seal */}
                <div className="border-b-2 border-cyan-500/50 pb-3 flex justify-between items-start">
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-cyan-400 font-bold print:text-blue-800">
                      NATIONAL AERONAUTICS AND SPACE ADMINISTRATION · JSC FLIGHT MEDICINE
                    </div>
                    <div className="text-lg font-bold text-slate-100 print:text-black">
                      BIOASTRONAUTICS TELEMETRY DISPOSITION & CLINICAL ORDERS
                    </div>
                    <div className="text-[11px] text-slate-400 print:text-gray-600">
                      SUBJECT: {crew.name} ({crew.role}) · ID: {crew.id} · CLASS I FLIGHT SURGEON ARCHIVE
                    </div>
                  </div>
                  <div className="text-right text-[10px] text-slate-500 font-mono print:text-gray-500">
                    <div>DOC-ID: NASA-HRP-{crew.id}-MET142</div>
                    <div>SECURITY: UNCLASSIFIED / MISSION CRITICAL</div>
                  </div>
                </div>

                {/* Formatted Markdown Body */}
                <div className="prose prose-invert max-w-none text-xs leading-relaxed space-y-3 font-mono print:prose">
                  {result.report.split('\n\n').map((paragraph, idx) => {
                    if (paragraph.startsWith('# ')) {
                      return (
                        <h1 key={idx} className="text-base font-bold text-cyan-300 pt-2 border-b border-slate-800 pb-1 print:text-blue-900">
                          {paragraph.replace('# ', '')}
                        </h1>
                      );
                    }
                    if (paragraph.startsWith('## ')) {
                      return (
                        <h2 key={idx} className="text-sm font-semibold text-slate-100 pt-1 print:text-black">
                          {paragraph.replace('## ', '')}
                        </h2>
                      );
                    }
                    if (paragraph.startsWith('### ')) {
                      return (
                        <h3 key={idx} className="text-xs font-bold text-cyan-400 pt-1 uppercase tracking-wider print:text-blue-800">
                          {paragraph.replace('### ', '')}
                        </h3>
                      );
                    }
                    if (paragraph.startsWith('- ') || paragraph.startsWith('1. ')) {
                      return (
                        <div key={idx} className="pl-3 border-l-2 border-slate-800 text-slate-300 space-y-1 print:text-gray-800">
                          {paragraph.split('\n').map((line, lIdx) => (
                            <div key={lIdx} className="leading-normal">
                              {line}
                            </div>
                          ))}
                        </div>
                      );
                    }
                    return (
                      <p key={idx} className="text-slate-300 leading-relaxed print:text-black">
                        {paragraph}
                      </p>
                    );
                  })}
                </div>

                {/* Official Sign-off Footer */}
                <div className="pt-4 border-t border-slate-800 text-[10px] text-slate-500 flex justify-between items-center print:text-gray-600">
                  <div>
                    CONFIDENTIAL BIOASTRONAUTICS HEALTH RECORD · VERIFIED AUTONOMOUS ENGINE
                  </div>
                  <div className="text-cyan-400 font-bold print:text-blue-800">
                    STATUS: FLIGHT READY & MONITORED
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-16 text-center space-y-3">
              <FileText className="w-10 h-10 text-cyan-400/40 mx-auto" />
              <div className="text-sm font-bold text-slate-300">
                Ready to synthesize NASA Flight Surgeon Clinical Brief
              </div>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Select your preferred AI engine (local offline Ollama, deep-space Gemini uplink, or Autonomous CDS) and clinical focus, then click Generate.
              </p>
              <button
                onClick={handleGenerate}
                className="px-5 py-2 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer inline-flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>GENERATE FOR {crew.name.toUpperCase()}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
