/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Stethoscope, 
  ChevronRight,
  ArrowRight
} from 'lucide-react';
import { TelemetryAlert } from '../types/telemetry';

interface ClinicalDecisionSupportProps {
  alerts: TelemetryAlert[];
  onAcknowledgeAlert: (alertId: string) => void;
  onOpenReportModal: () => void;
}

export const ClinicalDecisionSupport: React.FC<ClinicalDecisionSupportProps> = ({
  alerts,
  onAcknowledgeAlert,
  onOpenReportModal,
}) => {
  const unacknowledgedCount = alerts.filter((a) => !a.acknowledged).length;

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3.5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-cyan-950/80 border border-cyan-500/40 text-cyan-400">
            <Stethoscope className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold text-slate-100 text-xs">
                CLINICAL DECISION SUPPORT & ANOMALY MATRIX
              </span>
              {unacknowledgedCount > 0 && (
                <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  {unacknowledgedCount} PENDING ACTION
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              NASA Human Research Program (HRP) Bioastronautics Autonomous Triage
            </p>
          </div>
        </div>

        <button
          onClick={onOpenReportModal}
          className="flex items-center gap-1.5 font-mono text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
        >
          <span>Synthesize Flight Surgeon Brief</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Alerts list */}
      {alerts.length === 0 ? (
        <div className="bg-slate-950/60 rounded border border-slate-800/80 p-4 text-center font-mono text-xs text-slate-400">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
          <span>Zero physiological anomalies detected. All biomarkers within nominal boundaries.</span>
        </div>
      ) : (
        <div className="space-y-2.5">
          {alerts.map((alert) => {
            const isCritical = alert.severity === 'critical';
            const isWarning = alert.severity === 'warning';
            const isCaution = alert.severity === 'caution';

            return (
              <div
                key={alert.id}
                className={`p-3 rounded border font-mono transition-all ${
                  alert.acknowledged
                    ? 'bg-slate-950/40 border-slate-800/60 opacity-80'
                    : isCritical
                    ? 'bg-red-950/30 border-red-500/50 shadow-[0_0_12px_rgba(239,68,68,0.2)]'
                    : isWarning
                    ? 'bg-amber-950/20 border-amber-500/40'
                    : 'bg-slate-950 border-slate-800'
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2">
                    {isWarning || isCritical ? (
                      <AlertTriangle
                        className={`w-4 h-4 shrink-0 ${isCritical ? 'text-red-400' : 'text-amber-400'}`}
                      />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                    )}
                    <span className="font-bold text-slate-200 text-xs">{alert.title}</span>
                    <span className="text-[10px] text-slate-400">· {alert.category}</span>
                  </div>

                  <div className="flex items-center gap-2 text-[10px] text-slate-500">
                    <Clock className="w-3 h-3" />
                    <span>{alert.timestamp}</span>
                  </div>
                </div>

                {/* Metric Readout & Significance */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs mb-2 text-slate-300">
                  <div className="bg-slate-900/60 p-2 rounded border border-slate-800/80">
                    <span className="text-[10px] text-slate-400 block uppercase">{alert.metric} Telemetry:</span>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="font-bold text-cyan-300">{alert.currentValue}</span>
                      <span className="text-slate-500 text-[10px]">(Threshold: {alert.thresholdValue})</span>
                    </div>
                  </div>

                  <div className="bg-slate-900/60 p-2 rounded border border-slate-800/80 text-[11px] leading-relaxed text-slate-300">
                    <span className="text-[10px] text-slate-400 block uppercase">Clinical Significance:</span>
                    {alert.clinicalSignificance}
                  </div>
                </div>

                {/* Countermeasure directive and Action button */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/60 text-xs">
                  <div className="text-[11px] text-emerald-300/90 flex-1">
                    <span className="font-semibold text-emerald-400 uppercase text-[10px] mr-1.5">
                      Mandated Directive:
                    </span>
                    {alert.countermeasure}
                  </div>

                  {!alert.acknowledged ? (
                    <button
                      onClick={() => onAcknowledgeAlert(alert.id)}
                      className="px-3 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-semibold text-xs shadow-sm cursor-pointer transition-all shrink-0"
                    >
                      INSTITUTE COUNTERMEASURE
                    </button>
                  ) : (
                    <span className="font-mono text-[10px] text-slate-500 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      COUNTERMEASURE ACTIVE
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
