/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Eye, ShieldAlert, CheckCircle, AlertTriangle, ArrowUpRight, Activity } from 'lucide-react';
import { SansMetrics } from '../types/telemetry';

interface SansOcularMatrixProps {
  sans: SansMetrics;
  crewName: string;
}

export const SansOcularMatrix: React.FC<SansOcularMatrixProps> = ({ sans, crewName }) => {
  const onsdDangerLimit = 5.8;
  const isElevated = sans.opticNerveSheathDiameter >= onsdDangerLimit;

  // Percentage within normal/alert scale (4.0mm to 6.5mm)
  const onsdPercent = Math.min(
    100,
    Math.max(0, ((sans.opticNerveSheathDiameter - 4.0) / (6.5 - 4.0)) * 100)
  );

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between hover:border-slate-700 transition-all">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 mb-2.5">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-cyan-400" />
            <div>
              <span className="font-mono font-bold text-slate-200 text-xs block leading-tight">
                SANS & NEURO-OCULAR
              </span>
              <span className="font-mono text-[10px] text-slate-500">
                Cephalad Venous Stagnation Matrix
              </span>
            </div>
          </div>
          <span
            className={`font-mono text-[10px] px-2 py-0.5 rounded border ${
              isElevated
                ? 'bg-red-500/10 text-red-400 border-red-500/30 font-bold'
                : sans.opticNerveSheathDiameter > 5.2
                ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
            }`}
          >
            {sans.stage}
          </span>
        </div>

        {/* Primary ONSD Visual Gauge */}
        <div className="bg-slate-950 p-2.5 rounded border border-slate-800/80 mb-3">
          <div className="flex items-baseline justify-between mb-1.5 font-mono">
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Optic Nerve Sheath (ONSD)</span>
              <span className="text-2xl font-bold text-slate-100">{sans.opticNerveSheathDiameter}</span>
              <span className="text-xs text-slate-400 ml-1">mm</span>
            </div>
            <div className="text-right text-[10px]">
              <span className="text-slate-400 block">Upper Clinical Limit:</span>
              <span className="text-amber-400 font-semibold">{onsdDangerLimit} mm</span>
            </div>
          </div>

          {/* Bar Gauge with threshold indicator */}
          <div className="relative w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
            {/* Safe zone gradient */}
            <div
              className={`h-full transition-all duration-500 ${
                isElevated
                  ? 'bg-gradient-to-r from-emerald-500 via-amber-500 to-red-500'
                  : 'bg-gradient-to-r from-emerald-500 to-cyan-400'
              }`}
              style={{ width: `${onsdPercent}%` }}
            />
            {/* Threshold Marker at 5.8mm */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-red-400 shadow-[0_0_4px_rgba(248,113,113,1)] z-10"
              style={{ left: `${((5.8 - 4.0) / (6.5 - 4.0)) * 100}%` }}
              title="NASA Flight Surgeon Cutoff (5.80mm)"
            />
          </div>

          <div className="flex justify-between items-center text-[9px] font-mono text-slate-500 mt-1">
            <span>4.0 mm (Terrestrial)</span>
            <span className="text-red-400 font-semibold">5.8 mm Cutoff</span>
            <span>6.5 mm (Papilledema)</span>
          </div>
        </div>

        {/* Diagnostic Metrics Matrix */}
        <div className="grid grid-cols-2 gap-2 font-mono text-[11px] mb-3">
          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">Intraocular Pressure</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-slate-200">{sans.intraocularPressure}</span>
              <span className="text-[10px] text-slate-400">mmHg</span>
            </div>
          </div>

          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">Est. Intracranial Pr</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-slate-200">{sans.intracranialPressureEst}</span>
              <span className="text-[10px] text-slate-400">mmHg</span>
            </div>
          </div>

          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">Frisén Papilledema</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className={`font-bold ${sans.frisenGrade > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                Grade {sans.frisenGrade}
              </span>
              <span className="text-[10px] text-slate-400">of 4</span>
            </div>
          </div>

          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">Hyperopic Shift</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-cyan-300">+{sans.hyperopicShiftDiopters}</span>
              <span className="text-[10px] text-slate-400">Diopters</span>
            </div>
          </div>
        </div>
      </div>

      {/* SANS Countermeasure Protocol Order */}
      <div className="pt-2 border-t border-slate-800/80 font-mono text-[10px]">
        <div className="flex items-center justify-between text-slate-400 mb-1">
          <span className="text-slate-500">MANDATED COUNTERMEASURE:</span>
          <span className="text-cyan-400 font-semibold">LBNP Session</span>
        </div>
        <p className="text-slate-300 bg-slate-950 px-2 py-1.5 rounded border border-slate-800 leading-relaxed">
          {isElevated
            ? '60 min Lower Body Negative Pressure @ -25 mmHg scheduled prior to sleep window to draw 800mL fluid caudad.'
            : 'Nominal 30 min prophylactic LBNP cycle with Russian Chibis suit compliance active.'}
        </p>
      </div>
    </div>
  );
};
