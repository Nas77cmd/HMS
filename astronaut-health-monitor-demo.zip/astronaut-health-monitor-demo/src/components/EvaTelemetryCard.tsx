/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Space as SpaceIcon, Gauge, Battery, Flame, Shield, Droplets, Zap } from 'lucide-react';
import { EvaMetrics } from '../types/telemetry';

interface EvaTelemetryCardProps {
  eva: EvaMetrics;
  crewName: string;
}

export const EvaTelemetryCard: React.FC<EvaTelemetryCardProps> = ({ eva, crewName }) => {
  const [simulatedEva, setSimulatedEva] = useState(false);

  const isActive = eva.active || simulatedEva;
  const sortieName = eva.sortieName || 'EVA Sortie Simulation (Exterior Gateway Truss)';
  const btu = isActive ? (eva.metabolicRateBtu || 1280) : 380;
  const suitPressure = isActive ? (eva.suitPressurePsi || 4.28) : 14.7;
  const scrubber = isActive ? (eva.co2ScrubberRemainingPercent || 72) : 100;
  const battery = isActive ? (eva.batteryPercent || 78) : 100;

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between hover:border-slate-700 transition-all">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 mb-2.5">
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-cyan-400" />
            <div>
              <span className="font-mono font-bold text-slate-200 text-xs block leading-tight">
                EVA SUIT BIOMETRICS (EMU/xEMU)
              </span>
              <span className="font-mono text-[10px] text-slate-500">
                Life Support & Portable PLSS Telemetry
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            {!eva.active && (
              <button
                onClick={() => setSimulatedEva((s) => !s)}
                className="font-mono text-[9px] px-1.5 py-0.5 rounded border bg-slate-950 border-slate-800 text-cyan-400 hover:border-cyan-500/50"
              >
                {simulatedEva ? 'EXIT SIM' : 'SIMULATE EVA'}
              </button>
            )}
            <span
              className={`font-mono text-[10px] px-2 py-0.5 rounded border ${
                isActive
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30 font-bold animate-pulse'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {isActive ? 'ACTIVE EXTRAVEHICULAR' : 'IVA HABITAT MODE'}
            </span>
          </div>
        </div>

        {/* Primary Suit Status Banner */}
        <div className="bg-slate-950 p-2.5 rounded border border-slate-800/80 mb-3">
          <div className="flex items-baseline justify-between mb-1 font-mono">
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Suit Pressure (100% O2)</span>
              <span className="text-2xl font-bold text-slate-100">{suitPressure}</span>
              <span className="text-xs text-slate-400 ml-1">PSI</span>
            </div>
            <div className="text-right text-[10px]">
              <span className="text-slate-400 block">Metabolic Burn:</span>
              <span className="text-amber-400 font-semibold font-mono text-sm">{btu} BTU/hr</span>
            </div>
          </div>

          <div className="text-[10px] font-mono text-cyan-300 truncate">
            {isActive ? sortieName : 'Nominal Habitat Atmospheric Pressure (14.7 psi / 21% O2)'}
          </div>
        </div>

        {/* EMU Life Support Gauges */}
        <div className="grid grid-cols-2 gap-2 font-mono text-[11px] mb-3">
          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">LiOH CO2 Scrubber</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-emerald-400">{scrubber}%</span>
              <span className="text-[10px] text-slate-400">Remaining</span>
            </div>
          </div>

          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">PLSS Battery Reserve</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-slate-200">{battery}%</span>
              <span className="text-[10px] text-slate-400">4.2 hr Left</span>
            </div>
          </div>

          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">Cooling Water Loop</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-cyan-300">{isActive ? '14.2' : '--'}°C</span>
              <span className="text-[10px] text-slate-400">LCG Garment</span>
            </div>
          </div>

          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">Suit Leak Rate</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-slate-200">{isActive ? '85' : '0'}</span>
              <span className="text-[10px] text-slate-400">sccm (Nominal)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Safety Margin Callout */}
      <div className="pt-2 border-t border-slate-800/80 font-mono text-[10px]">
        <div className="flex items-center justify-between text-slate-400">
          <span>SECONDARY O2 BOTTLES:</span>
          <span className="text-emerald-400 font-semibold">100% PRESSURE (2,800 PSI)</span>
        </div>
      </div>
    </div>
  );
};
