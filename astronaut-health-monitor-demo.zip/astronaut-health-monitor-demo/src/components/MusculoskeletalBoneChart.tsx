/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Dumbbell, Bone, Flame, ShieldCheck, Check } from 'lucide-react';
import { Biomarkers, CircadianMetrics } from '../types/telemetry';

interface MusculoskeletalBoneChartProps {
  biomarkers: Biomarkers;
  circadian: CircadianMetrics;
  crewName: string;
}

export const MusculoskeletalBoneChart: React.FC<MusculoskeletalBoneChartProps> = ({
  biomarkers,
  circadian,
  crewName,
}) => {
  const [extraLoadApplied, setExtraLoadApplied] = useState(false);

  const bmdDelta = extraLoadApplied
    ? Number((biomarkers.boneMineralDensityChange + 0.3).toFixed(1))
    : biomarkers.boneMineralDensityChange;

  const sites = [
    { name: 'Lumbar Spine (L1-L4)', delta: bmdDelta, baselineLoss: -1.2 },
    { name: 'Femoral Neck', delta: Number((bmdDelta * 1.1).toFixed(1)), baselineLoss: -1.5 },
    { name: 'Calcaneus (Heel)', delta: Number((bmdDelta * 0.9).toFixed(1)), baselineLoss: -1.0 },
    { name: 'Gastrocnemius Muscle', delta: biomarkers.muscleMassChange, baselineLoss: -2.0 },
  ];

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between hover:border-slate-700 transition-all">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 mb-2.5">
          <div className="flex items-center gap-2">
            <Bone className="w-4 h-4 text-emerald-400" />
            <div>
              <span className="font-mono font-bold text-slate-200 text-xs block leading-tight">
                MUSCULOSKELETAL & ARED
              </span>
              <span className="font-mono text-[10px] text-slate-500">
                Trabecular Bone & Resistive Regimen
              </span>
            </div>
          </div>
          <span className="font-mono text-[10px] px-2 py-0.5 rounded border bg-emerald-500/10 text-emerald-400 border-emerald-500/30">
            {biomarkers.aredCompliancePercent}% ARED COMPLIANT
          </span>
        </div>

        {/* Anatomical Bone Density & Atrophy Breakdown */}
        <div className="space-y-2 mb-3">
          {sites.map((site) => {
            const isProtected = Math.abs(site.delta) < Math.abs(site.baselineLoss);
            return (
              <div
                key={site.name}
                className="bg-slate-950/70 p-2 rounded border border-slate-800/60 font-mono text-xs"
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="text-slate-300 font-medium text-[11px]">{site.name}</span>
                  <div className="flex items-center gap-2">
                    <span
                      className={`font-bold ${
                        site.delta > -1.0 ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {site.delta > 0 ? `+${site.delta}` : site.delta}%
                    </span>
                    <span className="text-[10px] text-slate-500">vs unmitigated ({site.baselineLoss}%)</span>
                  </div>
                </div>

                {/* Relative bar comparison */}
                <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden flex">
                  <div
                    className="h-full bg-emerald-500 transition-all"
                    style={{ width: `${Math.max(10, 100 - Math.abs(site.delta) * 35)}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Circadian Sleep & Biomarker Row */}
        <div className="grid grid-cols-3 gap-2 font-mono text-[10px] bg-slate-950 p-2 rounded border border-slate-800/80 mb-2">
          <div>
            <span className="text-slate-500 block">SLEEP SCORE</span>
            <span className="font-bold text-slate-200 text-xs">{circadian.sleepScore}/100</span>
          </div>
          <div>
            <span className="text-slate-500 block">CORTISOL SERUM</span>
            <span className="font-bold text-slate-200 text-xs">{biomarkers.cortisolSerumUgDl} µg/dL</span>
          </div>
          <div>
            <span className="text-slate-500 block">INFLAMMATION hsCRP</span>
            <span className="font-bold text-emerald-400 text-xs">{biomarkers.hsCRP} mg/L</span>
          </div>
        </div>
      </div>

      {/* Interactive ARED Countermeasure Stimulus */}
      <div className="pt-2 border-t border-slate-800/80 font-mono text-[10px]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-slate-400">
            <Dumbbell className="w-3.5 h-3.5 text-cyan-400" />
            <span>ARED High-Resistance Protocol:</span>
          </div>
          <button
            onClick={() => setExtraLoadApplied((v) => !v)}
            className={`px-2 py-0.5 rounded border transition-all ${
              extraLoadApplied
                ? 'bg-cyan-950 text-cyan-300 border-cyan-500/50'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            {extraLoadApplied ? 'LOAD +15% ACTIVE' : '+15% RESISTIVE BOOST'}
          </button>
        </div>
      </div>
    </div>
  );
};
