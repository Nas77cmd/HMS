/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Wifi, 
  Volume2, 
  VolumeX, 
  Cpu, 
  FileText, 
  Clock, 
  ShieldAlert, 
  Radio, 
  Settings2,
  ChevronRight,
  UserCheck
} from 'lucide-react';
import { CrewMember, OllamaStatus } from '../types/telemetry';

interface HeaderProps {
  crew: CrewMember[];
  selectedCrew: CrewMember;
  onSelectCrew: (crew: CrewMember) => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  ollamaStatus: OllamaStatus;
  onOpenOllamaConfig: () => void;
  onOpenReportModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  crew,
  selectedCrew,
  onSelectCrew,
  audioEnabled,
  onToggleAudio,
  ollamaStatus,
  onOpenOllamaConfig,
  onOpenReportModal,
}) => {
  // Live MET tick
  const [metSeconds, setMetSeconds] = useState(14 * 3600 + 22 * 60 + 45);
  const [commsDelay, setCommsDelay] = useState<'0s' | '1.3s' | '14m'>('0s');

  useEffect(() => {
    const timer = setInterval(() => {
      setMetSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatMet = (totalSec: number) => {
    const hours = Math.floor(totalSec / 3600);
    const minutes = Math.floor((totalSec % 3600) / 60);
    const seconds = totalSec % 60;
    return `+142d ${hours.toString().padStart(2, '0')}h ${minutes.toString().padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`;
  };

  return (
    <header className="border-b border-cyan-950/60 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
      {/* Top Telemetry Flight Ribbon */}
      <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Mission Identity & MET */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
            <span className="font-mono tracking-widest uppercase font-bold text-cyan-400 text-sm">
              FLIGHT SURGEON AI
            </span>
            <span className="text-slate-400 font-mono tracking-tight hidden sm:inline">
              · ARTEMIS IX BIOASTRONAUTICS CDS
            </span>
          </div>

          <div className="h-4 w-px bg-slate-800 hidden sm:block" />

          {/* Spacecraft MET Timer */}
          <div className="flex items-center gap-1.5 font-mono text-slate-300 bg-slate-900/90 px-2.5 py-1 rounded border border-slate-800">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[10px] text-slate-400 uppercase">MET:</span>
            <span className="text-cyan-300 font-semibold">{formatMet(metSeconds)}</span>
          </div>

          {/* Deep Space Latency Simulator */}
          <div className="hidden lg:flex items-center gap-1.5 text-slate-400 font-mono text-[11px]">
            <Radio className="w-3.5 h-3.5 text-slate-500" />
            <span>Earth Comms Uplink:</span>
            <div className="flex items-center bg-slate-900 rounded p-0.5 border border-slate-800 text-[10px]">
              {(['0s', '1.3s', '14m'] as const).map((delay) => (
                <button
                  key={delay}
                  onClick={() => setCommsDelay(delay)}
                  className={`px-2 py-0.5 rounded transition-all ${
                    commsDelay === delay
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title={
                    delay === '0s'
                      ? 'Direct low latency'
                      : delay === '1.3s'
                      ? 'Lunar Orbit delay'
                      : 'Mars Deep Space lag (Ollama offline autonomy required!)'
                  }
                >
                  {delay === '0s' ? 'Direct' : delay === '1.3s' ? 'Lunar (1.3s)' : 'Deep Space (14m)'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Global System Controls: Ollama Offline Status, Audio, Report Trigger */}
        <div className="flex items-center gap-2">
          {/* Audio Telemetry Toggle */}
          <button
            onClick={onToggleAudio}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border font-mono transition-all text-xs ${
              audioEnabled
                ? 'bg-cyan-950/60 text-cyan-300 border-cyan-500/40'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
            title={audioEnabled ? 'Telemetry Audio Active (Mute)' : 'Telemetry Audio Muted (Enable)'}
          >
            {audioEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                <span className="hidden md:inline">AUDIO ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5 text-slate-500" />
                <span className="hidden md:inline">AUDIO MUTED</span>
              </>
            )}
          </button>

          {/* Ollama Offline Status & Config Button */}
          <button
            onClick={onOpenOllamaConfig}
            className={`flex items-center gap-2 px-3 py-1 rounded border font-mono transition-all text-xs ${
              ollamaStatus.online
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300 hover:bg-emerald-950/60'
                : 'bg-amber-950/30 border-amber-500/30 text-amber-300 hover:bg-amber-950/50'
            }`}
            title="Configure Local Ollama Offline LLM"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span className="font-semibold">
              {ollamaStatus.online
                ? `Ollama: ${ollamaStatus.models[0]?.name ? ollamaStatus.models[0].name.split(':')[0] : 'Ready'}`
                : 'Ollama: Standby'}
            </span>
            <div
              className={`w-2 h-2 rounded-full ${
                ollamaStatus.online ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]' : 'bg-amber-400'
              }`}
            />
            <Settings2 className="w-3 h-3 text-slate-400" />
          </button>

          {/* Primary Action: Generate Flight Surgeon Report */}
          <button
            onClick={onOpenReportModal}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-semibold font-mono text-xs shadow-[0_0_12px_rgba(6,182,212,0.4)] transition-all cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>AI CLINICAL BRIEF</span>
          </button>
        </div>
      </div>

      {/* Crewmember Selector Bar */}
      <div className="bg-slate-900/60 border-t border-slate-900 px-4 py-2">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 overflow-x-auto scrollbar-thin">
          <div className="flex items-center gap-1.5 text-slate-400 text-xs font-mono shrink-0 mr-2">
            <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span className="uppercase tracking-wider">CREW COMPLEMENT:</span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {crew.map((member) => {
              const isSelected = member.id === selectedCrew.id;
              const hasAlert = member.alerts.some((a) => !a.acknowledged && a.severity !== 'nominal');

              return (
                <button
                  key={member.id}
                  onClick={() => onSelectCrew(member)}
                  className={`flex items-center gap-2.5 px-3 py-1.5 rounded transition-all text-left border ${
                    isSelected
                      ? 'bg-cyan-950/80 border-cyan-500/70 text-cyan-100 shadow-[0_0_10px_rgba(6,182,212,0.25)]'
                      : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:bg-slate-800/60 hover:border-slate-700'
                  }`}
                >
                  {/* Status Indicator */}
                  <div className="relative">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        member.overallStatus === 'nominal'
                          ? 'bg-emerald-400'
                          : member.overallStatus === 'caution'
                          ? 'bg-amber-400'
                          : 'bg-red-400 animate-ping'
                      }`}
                    />
                    {hasAlert && (
                      <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full bg-red-500" />
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-xs tracking-tight">{member.name}</span>
                      <span className="font-mono text-[10px] text-slate-400">({member.callsign})</span>
                      {member.eva.active && (
                        <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                          EVA
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 font-mono text-[10px] text-slate-400">
                      <span>{member.role.split('(')[1]?.replace(')', '') || member.role}</span>
                      <span className="text-slate-600">·</span>
                      <span className="text-cyan-300">{member.vitals.heartRate} BPM</span>
                      <span className="text-slate-600">·</span>
                      <span className="text-slate-300">SpO2 {member.vitals.spO2}%</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </header>
  );
};
