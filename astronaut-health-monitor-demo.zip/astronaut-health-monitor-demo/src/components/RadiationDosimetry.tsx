/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Radiation, Shield, AlertOctagon, Sun, ShieldCheck } from 'lucide-react';
import { RadiationMetrics } from '../types/telemetry';

interface RadiationDosimetryProps {
  radiation: RadiationMetrics;
  crewName: string;
}

export const RadiationDosimetry: React.FC<RadiationDosimetryProps> = ({ radiation, crewName }) => {
  const [shelterOverride, setShelterOverride] = useState(radiation.stormShelterActive);

  // NASA career limit calculation (600 mSv)
  const careerPercent = Math.min(
    100,
    ((radiation.careerCumulative / radiation.careerLimitMsv) * 100)
  ).toFixed(1);

  // 30-day rolling estimate vs 250 mSv limit
  const thirtyDayEst = (radiation.dailyRate * 30).toFixed(1);

  const isStormAlert = radiation.speRiskLevel !== 'Nominal';

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between hover:border-slate-700 transition-all">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 mb-2.5">
          <div className="flex items-center gap-2">
            <Radiation className="w-4 h-4 text-amber-400 animate-spin-slow" />
            <div>
              <span className="font-mono font-bold text-slate-200 text-xs block leading-tight">
                COSMIC DOSIMETRY
              </span>
              <span className="font-mono text-[10px] text-slate-500">
                GCR & Solar Particle Event (SPE)
              </span>
            </div>
          </div>
          <span
            className={`font-mono text-[10px] px-2 py-0.5 rounded border ${
              isStormAlert
                ? 'bg-red-500/10 text-red-400 border-red-500/30 font-bold animate-pulse'
                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
            }`}
          >
            {radiation.speRiskLevel}
          </span>
        </div>

        {/* Primary Cumulative Dose Readout */}
        <div className="bg-slate-950 p-2.5 rounded border border-slate-800/80 mb-3">
          <div className="flex items-baseline justify-between mb-1.5 font-mono">
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">Mission Cumulative</span>
              <span className="text-2xl font-bold text-slate-100">{radiation.accumulated.toFixed(1)}</span>
              <span className="text-xs text-slate-400 ml-1">mSv</span>
            </div>
            <div className="text-right text-[10px]">
              <span className="text-slate-400 block">Current Daily Rate:</span>
              <span className={`font-semibold ${radiation.dailyRate > 1.0 ? 'text-amber-400' : 'text-cyan-300'}`}>
                {radiation.dailyRate.toFixed(2)} mSv/day
              </span>
            </div>
          </div>

          {/* NASA Career Limit Progress */}
          <div className="space-y-1">
            <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
              <span>NASA Career Limit (600 mSv)</span>
              <span className="text-slate-200 font-semibold">{careerPercent}%</span>
            </div>
            <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className={`h-full transition-all duration-500 ${
                  Number(careerPercent) > 60
                    ? 'bg-amber-500'
                    : 'bg-gradient-to-r from-cyan-500 to-indigo-500'
                }`}
                style={{ width: `${careerPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Secondary Metrics Matrix */}
        <div className="grid grid-cols-2 gap-2 font-mono text-[11px] mb-3">
          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">30-Day Rolling Incurred</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-slate-200">{thirtyDayEst}</span>
              <span className="text-[10px] text-slate-400">/ 250 mSv Limit</span>
            </div>
          </div>

          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">GCR Flux Rate</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-slate-200">{radiation.gcrFluxRate}</span>
              <span className="text-[10px] text-slate-400">p/cm²·s</span>
            </div>
          </div>

          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">Career Total Cumulative</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-amber-300">{radiation.careerCumulative.toFixed(1)}</span>
              <span className="text-[10px] text-slate-400">mSv</span>
            </div>
          </div>

          <div className="bg-slate-950/70 p-2 rounded border border-slate-800/60">
            <span className="text-slate-500 text-[10px] block">Secondary Neutrons</span>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="font-bold text-slate-200">{radiation.secondaryNeutronFlux}</span>
              <span className="text-[10px] text-slate-400">mSv/hr</span>
            </div>
          </div>
        </div>
      </div>

      {/* Habitat Storm Shelter Toggle & Radioprotection */}
      <div className="pt-2 border-t border-slate-800/80 font-mono text-[10px]">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5 text-slate-400">
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            <span>Water-Wall Storm Shelter:</span>
          </div>
          <button
            onClick={() => setShelterOverride((s) => !s)}
            className={`px-2 py-0.5 rounded border transition-all ${
              shelterOverride
                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            {shelterOverride ? 'SEALED & ACTIVE' : 'STANDBY'}
          </button>
        </div>
        <p className="text-slate-400 bg-slate-950 px-2 py-1.5 rounded border border-slate-800 leading-relaxed">
          {shelterOverride
            ? 'Crew quarters encircled by 40cm H2O & polyethylene attenuator. -72% secondary flux reduction.'
            : 'Nominal cislunar transit shielding. Solar monitor satellite GOES-X online.'}
        </p>
      </div>
    </div>
  );
};
