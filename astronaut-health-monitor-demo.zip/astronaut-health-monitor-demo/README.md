# Astronaut Health Monitoring & AI Medical Officer

A premium, real-time astronaut biomedical telemetry dashboard with an
**offline-capable AI clinical report generator**, built for a NASA Space
Apps Challenge demo.

This is one team member's independent contribution: a self-contained web
dashboard + Node/Express server that can be dropped into the rest of the
team's project.

## What it does

- **Live vitals monitoring** — heart rate / ECG waveform, blood pressure,
  SpO2, core temperature, VO2 peak, rendered as animated, continuously
  updating charts.
- **SANS ocular risk tracking** — Spaceflight-Associated Neuro-ocular
  Syndrome metrics (optic nerve sheath diameter, staging).
- **Radiation dosimetry** — cumulative and daily GCR/SPE radiation exposure.
- **Musculoskeletal/bone density trend** — simulated DEXA-style bone
  mineral density change over mission time.
- **EVA (spacewalk) telemetry card** — suit status during extravehicular
  activity.
- **Clinical Decision Support** — a rule-based engine that flags
  out-of-range vitals even with no AI model connected.
- **AI Medical Officer report generator** — generates a full narrative
  flight-surgeon-style clinical report using, in order of preference:
  1. A **local Ollama model** running on your machine (fully offline, no
     API key, no internet required) — see `models/README.md`.
  2. Google Gemini, if you provide your own `GEMINI_API_KEY` (optional).
  3. A built-in autonomous rule-based report generator as a guaranteed
     fallback, so the feature always works even with nothing configured.

All telemetry in this demo is simulated/synthetic — no real patient or
personal data is used.

## Quick start (Windows)

Double-click **`start-demo.bat`**. It checks for Node.js, installs
dependencies on first run, and starts the dashboard at
`http://localhost:3000`.

## Quick start (any OS)

```bash
npm install
npm run dev
```
Then open `http://localhost:3000`.

## Enabling offline AI reports (optional but recommended for the demo)

1. Install Ollama: https://ollama.com/download
2. Pull a small, fast model: `ollama pull qwen2.5:7b` (or `qwen2.5:3b` for
   lighter hardware).
3. Leave Ollama running in the background.
4. In the dashboard header, open **AI Settings** and pick the model from
   the auto-detected list, then generate a report from any crew member's
   card. See `models/README.md` for more detail and alternative models.

No Ollama installed? The dashboard still works end-to-end — it automatically
falls back to its built-in clinical decision engine for reports.

## Project structure

```
server.ts                  Express server: serves the app + AI report API
src/App.tsx                Main dashboard layout
src/components/            Vitals, ECG, SANS, radiation, bone density, EVA,
                            clinical decision support and AI report UI
src/services/aiService.ts  Client-side Ollama/Gemini/fallback orchestration
src/data/crewData.ts       Simulated crew + telemetry generator
models/                    Notes + drop-zone for optional local model files
start-demo.bat             One-click Windows launcher for the demo
```

## Notes for integration

- This module is self-contained (its own `server.ts`/Express instance and
  its own `package.json`). To integrate into a larger team app, either run
  it as its own service and link to it, or lift `src/components/` and
  `src/services/aiService.ts` into a shared frontend and proxy the
  `/api/ai/report` and `/api/ollama/*` routes through your existing backend.
- No team/product name is baked into the UI — the header reads generically
  as "FLIGHT SURGEON AI" so your team can brand it however you like later.
